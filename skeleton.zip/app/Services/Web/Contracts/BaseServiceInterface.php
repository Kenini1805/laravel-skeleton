<?php


namespace App\Services\Web\Contracts;

interface BaseServiceInterface
{

}
