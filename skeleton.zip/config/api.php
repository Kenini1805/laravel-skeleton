<?php

return [
    'per_page' => 5,
    'max_per_page' => 1000,
];
