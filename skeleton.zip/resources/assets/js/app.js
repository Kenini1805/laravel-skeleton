
/**
 * First we will load all of this project's JavaScript dependencies
 */

require('./bootstrap');
